<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TestControllerMark
 *
 * @author mark
 */
class TestControllerMark extends CI_Controller {
    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->model("model");
        $this->load->library("unit_test");
    }
    
    public function index()
    {
        $this->testReceptDana();
        $this->testChatSvePoruke();
        $this->testDohvatiZadnjiIDPoruke();
        
        $this->load->view("testMark");
    }
    
    function testDohvatiZadnjiIDPoruke()
    {
        $exp = false;
        $data = $this->model->dohvatiZadnjiIDPoruke();
        if(isset($data)){
            $exp = true;
        }
        $this->unit->run($exp, true, "Zadnji ID Poruke uspesan");
    }
        
    function testReceptDana()
    {
        $exp = false;
        $data = $this->model->receptDana();
        if(isset($data))
        {
            $exp = true;
        }
        $this->unit->run($exp, true, "Recept dana uspesan");
        
    }
    
    function testChatSvePoruke()
    {
        $exp = false;
        $data = $this->model->dohvatiSvePoruke();
        if(isset($data))
        {
            $exp = true;
        }
        $this->unit->run($exp, true, "Chat Dohvati Sve Poruke Uspesan");
    }
}
?>
