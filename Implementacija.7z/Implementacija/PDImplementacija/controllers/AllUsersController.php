<?php
//Mark Jack Bouchakian 2013/0576 
class AllUsersController extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
         $this->load->helper("url");
        
        $this->load->model("model");
        
    }
    
    public function index(){
                    $sviKorisnici = $this->model->dohvatiSveKorisnike();
                    $arr = array(
                    "title" => "AdminSviKorisnici",
                    "page" => "adminSviKorisnici",
                     "data" => $sviKorisnici

                    );
                    $this->load->view("templates/pageAdmin",$arr);
    }
}
?>
