<?php

//Katarina Jaksic 2013/0618
class NapisiRecept extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('model');
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->library('form_validation');

    }
    public function index() {

        $this->form_validation->set_rules('naziv', 'Naziv', 'required|min_length[4]');
        $this->form_validation->set_rules('tekstRecepta', 'Tekst Recepta', 'required|min_length[10]');
        $this->form_validation->set_rules('vremePripreme', 'Vreme Pripreme', 'required|min_length[1]');
 
        
        if(!$this->form_validation->run())
        {
            $this->session->set_flashdata('imgMSG','<div class="alert alert-danger text-center">There is error uploading a photo! Please try again later</div>');
            $vrste = $this->model->dohvatiSveKategorijeRecepata();
        //Loading View
            $arr = array(
                       "title" => " ",
                       "page" => "napisiRecept",
                       "vrsteRecepta" => $vrste
                   );
            $this->load->view("templates/page", $arr);
        }
        else
        {
            $id = $this->session->userdata('idKorisnika');
            $naziv = $this->input->post('naziv');
            $tekst = $this->input->post('tekstRecepta');
            $vremePripreme = $this->input->post('vremePripreme');
            $vrsta = $this->input->post('vrsta');
            $kategorija = $this->input->post('kategorijaRecepta');

            $config['upload_path'] = '/uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = 2048000;
            $config['max_width'] = 1024;
            $config['max_height'] = 768;

            $this->load->library('upload',$config);
            $this->upload->do_upload();
            $this->model->sacuvajRecept($id, $naziv, $tekst, $vremePripreme, $vrsta, $kategorija, $this->upload->data());
            
            $this->session->set_flashdata('imgMSG','<div class="alert alert-success text-center">Successfull !!!</div>');
            
             $vrste = $this->model->dohvatiSveKategorijeRecepata();
            $arr = array(
                       "title" => " ",
                       "page" => "napisiRecept",
                       "vrsteRecepta" => $vrste
                   );
            $this->load->view("templates/page", $arr);
        }

    }
   

}



?>