

<?php
//Jovana Vukovic 2013/0101
class SviRecepti extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model("model");
        $this->load->library("session");
        $this->load->helper("url");
        $this->load->library("form_validation");
        $this->load->helper("security");
    }
    
    public function index() {
        echo $this->session->flashdata("recepti");
        $data = $this->model->dohvatiSviRecepti();
        $arr = array(
            "title" => " ",
            "page" => "sviRecepti",
            "data" => $data
        );
        $this->load->view("templates/page", $arr);
    }
     
}
?>