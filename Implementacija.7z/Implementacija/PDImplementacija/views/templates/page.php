<?php
$this->load->view("templates/header");
$this->load->view($page);
$this->load->view("templates/footer");
?>

