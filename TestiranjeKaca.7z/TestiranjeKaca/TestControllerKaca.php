﻿<?php


class TestControllerKaca extends CI_Controller {
    
    
    public function __construct() {
        parent::__construct();
        $this->load->library("unit_test");
        $this->load->model("model");
    }
    
    public function index()
    {
       
      //Testovi za pregled predjela
      $this->testPredjelaNeuspesan("10");
      $this->testPredjelaUspesan("1"); 

      //Testovi za pregled salata
      $this->testSalataNeuspesan("10");
      $this->testSalataUspesan("2"); 
        
      //Testovi za pregled supa i corba
      $this->testSupeICorbeNeuspesan("10");
      $this->testSupeICorbeUspesan("3");
      
      //Testovi za pregled glavnih jela
       $this->testGlavnaJelaNeuspesan("10");
       $this->testGlavnaJelaUspesan("4");
      
      //Testovi za pregled dezerta
       $this->testDezertiNeuspesan("10");
       $this->testDezertiUspesan("5");
       
       
      //Testovi za pregled romanticnih vecera
       $this->testRomanticnaVeceraNeuspesan("Porodični ručak");
       $this->testRomanticnaVeceraUspesan("Romantična večera");
       
      //Testovi za pregled porodicnih ruckova
       $this->testPorodicniRucakNeuspesan("Romantična večera");
       $this->testPorodicniRucakUspesan("Porodični ručak"); 
       
        
       $this->load->view("testsKaca");
    }
    
    function testPredjelaNeuspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data, NULL, "Predjela ne postoje.");
    }
    
    function testPredjelaUspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data[1]->idKategorijaR, $id ,"Predjela postoje.");
    }
    
    function testSalataNeuspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data, NULL, "Salate ne postoje.");
    }
    
    function testSalataUspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data[0]->idKategorijaR, $id ,"Salate postoje.");
    }
    
    function testSupeICorbeNeuspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data, NULL, "Supe i corbe ne postoje.");
    }
    
     function testDezertiNeuspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data, NULL, "Dezerti ne postoje.");
    }
    
    function testDezertiUspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data[0]->idKategorijaR, $id ,"Dezerti postoje.");
    }
    
    function testSupeICorbeUspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data[0]->idKategorijaR, $id ,"Supe i corbe postoje.");
    }
    
    function testGlavnaJelaNeuspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data, NULL, "Glavna jela ne postoje.");
    }
    
    function testGlavnaJelaUspesan($id)
    {
        $data = $this->model->dohvatiReceptePoIDKategoriji($id);
        $this->unit->run($data[0]->idKategorijaR, $id ,"Glavna jela postoje.");
    }
    
    
    function testRomanticnaVeceraNeuspesan($vrsta)
    {
        $data = $this->model->dohvatiReceptePoVrsti($vrsta);
        $this->unit->run($data, NULL, "Recepti Romanticna vecera ne postoje.");
    }
    
    function testRomanticnaVeceraUspesan($vrsta)
    {
        $data = $this->model->dohvatiReceptePoVrsti($vrsta);
        $this->unit->run($data[0]->vrsta, $vrsta ,"Recepti Romanticna vecera postoje.");
    }
    
    function testPorodicniRucakNeuspesan($vrsta)
    {
        $data = $this->model->dohvatiReceptePoVrsti($vrsta);
        $this->unit->run($data, NULL, "Recepti Porodicni rucak ne postoje.");
    }
    
    function testPorodicniRucakUspesan($vrsta)
    {
        $data = $this->model->dohvatiReceptePoVrsti($vrsta);
        $this->unit->run($data[0]->vrsta, $vrsta ,"Recepti Porodicni Rucak postoje.");
    }
    
}

?>
