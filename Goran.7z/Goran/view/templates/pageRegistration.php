<?php
$this->load->view("templates/headerRegistration");
$this->load->view($page);
$this->load->view("templates/footer");
?>
