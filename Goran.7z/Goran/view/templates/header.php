<!DOCTYPE html>
<html lang="en">
<head>
    
        
        <link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>" />
</head>
<body>
    
    
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Perfect Dish</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Svi recepti</a></li>
            <li><a href="#about">Moji recepti</a></li>
            <li><a href="#contact">Recept dana</a></li>
            <li><a href ="#"> Napisi recept</a><li>
            <li><a href ="#"> Porodicni rucak</a><li>
            <li><a href ="#"> Romanticna vecera</a></li>
            <li><a href ="http://localhost/perfectdish/index.php/EmailController/index"> Pitajte Kuvara</a><li>
            <li><a href ="http://localhost/perfectdish/index.php/ChatController/index"> Chat</a><li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

     
<div id="container">
	
        
	<div id="body">


