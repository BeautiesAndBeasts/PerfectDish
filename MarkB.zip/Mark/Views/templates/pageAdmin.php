<?php
$this->load->view("templates/headerAdmin");
$this->load->view($page);
$this->load->view("templates/footer");
?>

