<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Model
 *
 * @author goran
 */

class Model extends CI_Model {
 
    
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    public function login($username, $password)
    {
        
        $this->db->where('korisnickoIme', $username);
        $this->db->where('lozinka', $password);
        $this->db->limit(1);
        
         $query = $this -> db -> get("registrovanikorisnik");
        
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function adminLogin($username,$password)
    {
        $this->db->where('korisnickoIme', $username);
        $this->db->where('lozinka', $password);
        $this->db->limit(1);
        
        $query = $this->db->get("administrator");
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function jedinstvenoKorisnickoIme($username)
    {
        $this->db->where('korisnickoIme',$username);
        $this->db->limit(1);
        $query = $this->db->get("registrovanikorisnik");
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function jedinstveniEmail($email)
    {
        $this->db->where('email',$email);
        $this->db->limit(1);
        $query = $this->db->get("registrovanikorisnik");
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function jedinstvenoAdminIme($username)
    {
        $this->db->where('korisnickoIme',$username);
        $this->db->limit(1);
        $query = $this->db->get("administrator");
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function registrujKorisnika()
    {
        $korisnickoIme = $this->input->post('korisnickoIme');
            $lozinka = $this->input->post('lozinka');
            $ime = $this->input->post('ime');
            $prezime = $this->input->post('prezime');
            $email = $this->input->post('email');
            
        $data = array(
            "korisnickoIme" => $korisnickoIme,
            "lozinka" => $lozinka,
            "ime" => $ime,
            "prezime" => $prezime,
            "email" => $email,
            "statusValidnosti" => "DA",
            "statusTrenutneAktivnosti" => "DA"
        );
        $this->db->insert('registrovanikorisnik',$data);
    }
    
    public function registrujAdmina()
    {
        $korisnickoIme = $this->input->post('korisnickoIme');
            $lozinka = $this->input->post('lozinka');
            $ime = $this->input->post('ime');
            $prezime = $this->input->post('prezime');
            $email = $this->input->post('email');
            
        $data = array(
            "korisnickoIme" => $korisnickoIme,
            "lozinka" => $lozinka,
            "ime" => $ime,
            "prezime" => $prezime,
            "email" => $email
        );
        $this->db->insert('administrator',$data);
    }
    
    public function dohvatiSveKorisnike()
    {
        $query = $this->db->get("registrovanikorisnik");
        return $query->result();
    }
    
    public function dohvatiSvePoruke()
    {
        $query = $this->db->get("poruke");
        return $query->result();
    }
    
    public function dohvatiZadnjiIDPoruke() 
    {
        $this->db->order_by("idPoruke", "desc");
        $this->db->limit(1);
        
        $query = $this->db->get("poruke");
         if($query->num_rows() != 0)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function posaljiPoruku($poruka, $time, $id)
    {
       
         $data = array(
            "sadrzajPoruke" => $poruka,
            "vremeSlanja" => $time,
             "idKorisnika" => $id
        );
        $this->db->insert('poruke',$data);
    }
    
    public function vratiKorisnickoPoIdu($id)
    {
        $this->db->where('idKorisnika',$id);
        $this->db->limit(1);
        
         $query = $this -> db -> get("registrovanikorisnik");
        
        if($query->num_rows() == 1)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
        
    }
    public function dohvatiKorisnikaPoID($id) {
        return $this->db->get_where("registrovanikorisnik", array("idKorisnika"=>$id))->result();
    }
    
    public function dohvatiSveRecepteKorisnika($id)
    {
        $this->db->where('idKorisnika',$id);
        
        $query = $this->db->get("recepti");
        if($query->num_rows() > 0)
        {
            return $query->result();
         
        }
        else
        {
            return false;
        }
    }
    
    public function dohvatiSvePorukeSaKorisnicima(){
        $this->db->select('*');
        $this->db->from('poruke');
        $this->db->join('registrovanikorisnik','registrovanikorisnik.idKorisnika = poruke.idKorisnika');
        $query = $this->db->get();
        return $query->result();
        
    }
    public function obrisiKorisnika($id) {
        $this->db->where("idKorisnika", $id);
        $this->db->delete("registrovanikorisnik");
    }
    
}
    

?>
