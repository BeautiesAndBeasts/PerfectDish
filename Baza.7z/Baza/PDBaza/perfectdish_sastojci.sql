-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: perfectdish
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sastojci`
--

DROP TABLE IF EXISTS `sastojci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sastojci` (
  `idSastojak` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) NOT NULL,
  `idKategorijaS` int(11) NOT NULL,
  PRIMARY KEY (`idSastojak`),
  KEY `fk_Sastojci_KategorijaSastojaka1_idx` (`idKategorijaS`),
  CONSTRAINT `fk_Sastojci_KategorijaSastojaka1` FOREIGN KEY (`idKategorijaS`) REFERENCES `kategorijasastojaka` (`idKategorijaS`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sastojci`
--

LOCK TABLES `sastojci` WRITE;
/*!40000 ALTER TABLE `sastojci` DISABLE KEYS */;
INSERT INTO `sastojci` VALUES (1,'Piletina',1),(2,'Teletina',1),(3,'Svinjetina',1),(4,'Junetina',1),(5,'Ćuretina',1),(6,'Jagnjetina',1),(7,'Šunka',1),(8,'Kisela pavlaka',2),(9,'Slatka pavlaka',2),(10,'Jogurt',2),(11,'Mleko',2),(12,'Kiselo mleko',2),(13,'Feta sir',2),(14,'Kačkavalj',2),(15,'Puter',2),(16,'Gambori',3),(17,'Hobotnica',3),(18,'Losos',3),(19,'Lignje',3),(20,'Pastrmka',3),(21,'Skuša',3),(22,'Som',3),(23,'Tuna',3),(24,'Šaran',3),(25,'Škarpina',3),(26,'Morski plodovi',3),(27,'Banana',4),(28,'Boranija',4),(29,'Breskva',4),(30,'Beli luk',4),(31,'Borovnica',4),(32,'Celer',4),(33,'Cvekla',4),(34,'Crni luk',4),(35,'Grašak',4),(36,'Jabuka',4),(37,'Jagoda',4),(38,'Kajsija',4),(39,'Kupus',4),(40,'Krompir',4),(41,'Krastavac',4),(42,'Karfiol',4),(43,'Limun',4),(44,'Malina',4),(45,'Paprika',4),(46,'Paradajz',4),(47,'Pirinač',4),(48,'Pasulj',4),(49,'Pomorandža',4),(50,'Praziluk',4),(51,'Ribizle',4),(52,'Višnje',4),(53,'Pečurke',4),(54,'Šljive',4),(55,'Spanać',4),(56,'Šargarepa',4),(57,'Tikvice',4),(58,'Zelena salata',4),(59,'Aleva paprika',5),(60,'Biber',5),(61,'Bosiljak',5),(62,'Cimet',5),(63,'Đumbir',5),(64,'Kari',5),(65,'Kim',5),(66,'Korijander',5),(67,'Lovorov list',5),(68,'Nana',5),(69,'Origano',5),(70,'Peršun',5),(71,'Ruzmarin',5),(72,'Mirođija',5),(73,'Šafran',5),(74,'So',5),(75,'Jaja',6),(76,'Suncokretovo ulje',6),(77,'Maslinovo ulje',6),(78,'Sirće',6),(79,'Kukuruzno brašno',6),(80,'Heljdino brašno',6),(81,'Pšenično brašno',6),(82,'Šećer',6),(83,'Šećer u prahu',6),(84,'Hleb',6),(85,'Džem',6),(86,'Crna čokolada',6),(87,'Bela čokolada',6),(88,'Kakao',6),(89,'Kečap',6),(90,'Griz',6),(91,'Kafa',6),(92,'Majonez',6),(93,'Šlag',6),(94,'Senf',6),(95,'Keks',6),(96,'Piškote',6),(97,'Margarin',6),(98,'Želatin',6),(99,'Kvasac',6),(100,'Vanilin šećer',6),(101,'Masline',6),(102,'Mix povrće',6),(103,'Kiseli krastavčići',6),(104,'Čili paprika',4),(105,'Slanina',1),(106,'Maslac',2),(107,'Kocka za supu',6),(108,'Brokoli',4),(109,'Soja sos',6),(110,'Mleveno meso',1),(111,'Prašak za pecivo',6),(112,'Kokos',6);
/*!40000 ALTER TABLE `sastojci` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-04  3:41:41
